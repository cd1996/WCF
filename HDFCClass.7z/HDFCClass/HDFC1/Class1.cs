﻿using System;

namespace HDFC1
{
    public class Class1
    {
    }
}
