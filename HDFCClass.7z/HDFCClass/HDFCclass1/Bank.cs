﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace HDFCclass1
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public  class Bank : IBank
    {
         int counter = 0;
        public string Deposite()
        {
            return "Deposited"+DateTime.Now.ToString();
        }

        public string Increment()
        {
           return "Counter:"+counter++;
        }

        public string Withdraw()
        {
            return "Withdraw" + DateTime.Now.ToString();
        }
    }
}
