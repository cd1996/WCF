﻿using System;
using System.ServiceModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HDFCclass1
{[ServiceContract]
    interface IBank
    {
        [OperationContract]
        string Deposite();

        [OperationContract]
        string Withdraw();


        [OperationContract]
        string Increment();
    }
}
