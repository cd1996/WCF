﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HDFCClass
{
    interface IBank
    {
        [ServiceContract]
        string Deposite();
        string Withdraw();
    }
}
